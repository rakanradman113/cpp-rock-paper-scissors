#include <iostream>
#include <stdlib.h>
#include <ctime>
#include <limits>



int getComputerChoice(){

int computer = rand() % 3 + 1;

return computer;

}


int getUserChoice(){

int user = 0;

std::cout << "===================\n";
std::cout << "rock paper scissors\n";
std::cout << "===================\n";

std::cout << "1) ✊\n";
std::cout << "2) 🤚\n";
std::cout << "3) ✌️\n";
std::cout << "SHOOT!\n";

std::cin >> user;

while (user < 1 || user > 3){
    std::cout << "This is an invalid choice enter a value from 1 to 3 only\n";
    std::cout << "Enter again: ";
    std::cin >> user;
}

return user;

}


void showResult(int user, int computer){



if (user == 1) {
  std::cout << "You choose ✊\n";
}
else if (user == 2) {
    std::cout << "You chose 🤚\n";
}
else {
    std::cout << "You chose ✌️\n";
}


if (computer == 1) {
  std::cout << "CPU chose ✊\n";
}
else if (computer == 2) {
    std::cout << "CPU chose 🤚\n";
}
else {
    std::cout << "CPU chose ✌️\n";
}

if (computer == user) {
  std::cout << "Tie!\n";
}

else if (user == 1) {
  if (computer == 2) {
    std::cout << "YOU LOSE\n";
  }

  if (computer == 3) {
    std::cout << "YOU WIN\n";
  }
}

else if (user == 2) {
  if (computer == 1) {
    std::cout << "YOU WIN\n";
  }

  if (computer == 3) {
    std::cout << "YOU LOSE\n";
  }
}

else if (user == 3) {
  if (computer == 1) {
    std::cout << "YOU LOSE\n";
  }

  if (computer == 2) {
    std::cout << "YOU WIN\n";
  }

}



}


int main() {

srand(time(NULL));

int computer = getComputerChoice();

int user = getUserChoice();



showResult(user, computer);

  return 0;
}
